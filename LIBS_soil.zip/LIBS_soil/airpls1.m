clc;clear
%% 惩罚最小二乘法
data_matrix=readmatrix('标准.txt', 'Delimiter', ' ');
 [m,n]=size(data_matrix);
A=data_matrix(1:end,:);
xbc2=[];
for i=2:n
xx=A(:,1);   %%%%% LIBS波长 x
xx=xx';
x1=A(:,i);    %%%%% LIBS强度 y
x1=x1';
%x=p3;
lambda1=200; %%%%% 平滑程度 待修改
[xbc1,xb1]=airPLS(x1, lambda1,2,0.01,0.05,50);
figure
subplot(2,1,1);
plot(xx,x1,'r')
hold on
plot(xx,xb1,'k','linewidth',2)
subplot(2,1,2);
plot(xx,xbc1,'b','linewidth',1)  %%%%% 最终数据
% 将校正后的光谱存储到矩阵中
    if isempty(xbc2)
        xbc2 = xbc1';  % 如果是第一个光谱，直接存储为列向量
    else
        xbc2 = [xbc2, xbc1'];  % 后续光谱作为新列添加
    end
   
end
