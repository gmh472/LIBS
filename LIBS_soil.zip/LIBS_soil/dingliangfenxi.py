import os

import numpy as np
import pandas as pd
import scipy.io
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, TensorDataset

# 导入modle.py中的模型
from modle import CNNInceptionHuigui, set_seed

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


def dlxl(file_path, save_model=True):
    """
    主要处理函数 - 数据加载、预处理、模型训练和评估

    参数:
        file_path (str): 数据文件路径
    """
    # 设置随机种子
    set_seed(3)  # 使用modle.py中的set_seed函数
    np.random.seed(3)

    # 1. 加载数据
    # 假设数据是文本格式，以空格分隔
    data = pd.read_csv(file_path, sep='\s+').values
    labels = data[0:4, 1:].T  # 修改为读取4行标签，因为新模型输出4个元素

    # 对标签进行归一化处理
    label_scalers = []  # 存储每个标签的归一化器
    labels_normalized = np.zeros_like(labels, dtype=np.float32)

    # 对每个标签分别进行归一化
    for i in range(labels.shape[1]):
        scaler = MinMaxScaler()
        labels_normalized[:, i] = scaler.fit_transform(labels[:, i].reshape(-1, 1)).flatten()
        label_scalers.append(scaler)
        print(f"标签{i + 1}范围: [{labels[:, i].min():.2f}, {labels[:, i].max():.2f}] -> [0, 1]")

    # 2. 加载RF特征筛选后的波段数据
    # 注意：需要调整
    RF = np.load('RF.npy')
    # data中第一列元素与RF相同的行
    ys = data[np.isin(data[:, 0], RF)]

    # 提取波长和特征
    ysl =ys[:, 0]  # 波长
    features = ys[:, 1:]  # 特征数据

    # 归一化特征
    scaler = MinMaxScaler()
    features_normalized = scaler.fit_transform(features).T

    # 4. 重塑数据为方阵
    n_samples = features_normalized.shape[0]
    n = int(np.ceil(np.sqrt(features_normalized.shape[1])))

    # 创建方阵的三维数组
    square_matrices = np.zeros((n_samples, n, n))

    # 将每个样本填充到对应的方阵
    for j in range(n_samples):
        sample = features_normalized[j]
        num_elements = len(sample)

        # 填充方阵
        for i in range(num_elements):
            row = i % n
            col = i // n
            square_matrices[j, row, col] = sample[i]

    # 3. 数据集划分 (70% 训练, 30% 测试)
    indices = np.arange(n_samples)
    np.random.shuffle(indices)

    split_idx = int(0.8 * n_samples)
    train_indices = indices[:split_idx]
    test_indices = indices[split_idx:]

    train_data = square_matrices[train_indices]
    test_data = square_matrices[test_indices]
    train_labels = labels_normalized[train_indices]  # 使用归一化后的标签
    test_labels = labels_normalized[test_indices]  # 使用归一化后的标签

    # 添加通道维度 (PyTorch要求: [batch, channels, height, width])
    train_data = np.expand_dims(train_data, axis=1)
    test_data = np.expand_dims(test_data, axis=1)

    # 转换为PyTorch张量
    train_data_tensor = torch.tensor(train_data, dtype=torch.float32)
    train_labels_tensor = torch.tensor(train_labels, dtype=torch.float32)
    test_data_tensor = torch.tensor(test_data, dtype=torch.float32)
    test_labels_tensor = torch.tensor(test_labels, dtype=torch.float32)

    # 创建数据集和数据加载器
    train_dataset = TensorDataset(train_data_tensor, train_labels_tensor)
    test_dataset = TensorDataset(test_data_tensor, test_labels_tensor)

    # 7. 创建模型 - 使用CNNInceptionHuigui替代MultiBranchCNN
    model = CNNInceptionHuigui(input_size=n)
    # +++ 在这里添加参数量统计代码 +++
    total_params = sum(p.numel() for p in model.parameters())
    print(f"模型总参数量: {total_params:,}")
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"可训练参数量: {trainable_params:,}")
    # +++ 参数量统计代码结束 +++
    # 8. 训练模型
    # 设置训练参数
    learning_rate = 0.001  # 降低学习率，更稳定收敛
    batch_size = 32  # 增加批次大小，提高训练稳定性
    num_epochs = 300  # 增加最大epoch数，让早停机制发挥作用
    weight_decay = 0.001  # 减小L2正则化强度

    # 早停参数
    patience = 20  # 减少耐心值，更早停止过拟合
    min_delta = 0.0005  # 减小最小变化量，更敏感地检测改进
    best_loss = float('inf')
    patience_counter = 0

    # 创建数据加载器
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    # 定义损失函数和优化器 - 修改为四个目标的平均损失
    criterion = nn.MSELoss(reduction='mean')  # 默认就是mean，但明确指定
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=weight_decay)

    # 使用更智能的学习率调度器 - 基于验证损失减少学习率
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode='min',
        factor=0.5,  # 当指标停止改进时，将学习率减半
        patience=10,  # 等待10个epoch没有改进
        min_lr=1e-6  # 最小学习率
    )

    # 训练循环
    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0

        for inputs, targets in train_loader:
            optimizer.zero_grad()

            outputs = model(inputs)
            # 计算四个目标的平均损失
            loss = criterion(outputs, targets)
            loss.backward()

            # 添加梯度裁剪，防止梯度爆炸
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

            optimizer.step()

            running_loss += loss.item() * inputs.size(0)

        # 计算验证损失
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for inputs, targets in test_loader:
                outputs = model(inputs)
                loss = criterion(outputs, targets)
                val_loss += loss.item() * inputs.size(0)

        val_loss = val_loss / len(test_loader.dataset)

        # 根据验证损失更新学习率
        scheduler.step(val_loss)

        epoch_loss = running_loss / len(train_loader.dataset)
        current_lr = optimizer.param_groups[0]['lr']
        print(
            f'Epoch [{epoch + 1}/{num_epochs}], Loss: {epoch_loss:.4f}, Val Loss: {val_loss:.4f}, LR: {current_lr:.6f}')

        # 早停机制 - 基于验证损失而非训练损失
        if val_loss < best_loss - min_delta:
            best_loss = val_loss
            patience_counter = 0
            # 保存最佳模型
            if save_model:
                torch.save({
                    'model_state_dict': model.state_dict(),
                    'input_size': n,
                    'scaler_params': {
                        'data_min': scaler.data_min_,
                        'data_max': scaler.data_max_
                    },
                    'label_scalers': [  # 保存标签归一化器参数
                        {
                            'data_min': label_scalers[i].data_min_[0],
                            'data_max': label_scalers[i].data_max_[0]
                        } for i in range(len(label_scalers))
                    ],
                    'val_loss': val_loss,  # 保存验证损失
                    'epoch': epoch  # 保存epoch数
                }, 'trained_modelyuansu.pth')
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"早停触发，在 epoch {epoch + 1} 停止训练")
                break

    # 9. 评估模型
    # 加载最佳模型
    if save_model:
        checkpoint = torch.load('trained_modelyuansu.pth')
        model.load_state_dict(checkpoint['model_state_dict'])
        print("已加载最佳模型进行评估")

    model.eval()
    all_predictions = []
    all_targets = []

    with torch.no_grad():
        for inputs, targets in test_loader:
            outputs = model(inputs)
            all_predictions.append(outputs.numpy())
            all_targets.append(targets.numpy())

    predictions = np.vstack(all_predictions)
    targets = np.vstack(all_targets)

    # 将负值设为0
    predictions[predictions < 0] = 0

    # 反归一化预测值和真实值
    predictions_original = np.zeros_like(predictions)
    targets_original = np.zeros_like(targets)

    for i in range(predictions.shape[1]):
        # 将预测值反归一化到原始范围
        predictions_original[:, i] = label_scalers[i].inverse_transform(
            predictions[:, i].reshape(-1, 1)
        ).flatten()

        # 将真实值反归一化到原始范围
        targets_original[:, i] = label_scalers[i].inverse_transform(
            targets[:, i].reshape(-1, 1)
        ).flatten()

    # 10. 计算R²并绘图
    r_squared = []
    for i in range(targets_original.shape[1]):  # 对每个输出
        # 计算R²
        ss_res = np.sum((targets_original[:, i] - predictions_original[:, i]) ** 2)
        ss_tot = np.sum((targets_original[:, i] - np.mean(targets_original[:, i])) ** 2)
        r2 = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0
        r_squared.append(r2)

        # 绘制散点图
        plt.figure()
        plt.scatter(targets_original[:, i], predictions_original[:, i], alpha=0.6)

        # 添加对角线
        min_val = min(np.min(targets_original[:, i]), np.min(predictions_original[:, i]))
        max_val = max(np.max(targets_original[:, i]), np.max(predictions_original[:, i]))
        plt.plot([min_val, max_val], [min_val, max_val], 'r-')

        plt.xlabel('真实值(ppm)')
        plt.ylabel('预测值(ppm)')
        plt.title('标准样品元素分析')

        # 添加R²值
        plt.text(0.05, 0.95, f'R2 = {r2:.4f}',
                 transform=plt.gca().transAxes, fontsize=12,
                 verticalalignment='top')

        # 确保保存路径存在
        save_path = '训练'
        if not os.path.exists(save_path):
            os.makedirs(save_path)

        # 假设 r2 和 i 已经在代码中定义
        plt.savefig(os.path.join(save_path, f'scatter_plot_{i + 1}_R2_{r2:.4f}.png'))
        plt.close()  # 关闭当前图形，避免占用内存

    # 保存波长
    np.save('ysl.npy', ysl)
    return n, ysl


# 使用示例
if __name__ == "__main__":
    # 替换为实际文件路径
    file_path = "C:/LIBS车载/标准文件/车载四元素.csv"
    n, ysl = dlxl(file_path)

    print(f"方阵大小: {n}")
    print(f"波长数据: {ysl[:5]} ...")