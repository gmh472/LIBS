from random import random

import networkx as nx
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from matplotlib import pyplot as plt


# 固定所有随机种子
def set_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class ResidualBlock(nn.Module):
    """残差块模块"""

    def __init__(self, in_channels, out_channels, stride=1):
        super(ResidualBlock, self).__init__()

        # 第一个卷积层
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.LeakyReLU(negative_slope=0.02, inplace=True)
        )

        # 第二个卷积层
        self.conv2 = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(out_channels)
        )

        # 下采样层（如果需要调整维度）
        self.downsample = None
        if stride != 1 or in_channels != out_channels:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride),
                nn.BatchNorm2d(out_channels)
            )

        self.relu = nn.LeakyReLU(negative_slope=0.02, inplace=True)

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.conv2(out)

        if self.downsample is not None:
            identity = self.downsample(identity)

        out += identity
        return self.relu(out)


class ChannelAttention(nn.Module):
    """通道注意力模块（Squeeze-and-Excitation）"""

    def __init__(self, in_channels, reduction_ratio=8):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc = nn.Sequential(
            nn.Linear(in_channels, in_channels // reduction_ratio),
            nn.ReLU(inplace=True),
            nn.Linear(in_channels // reduction_ratio, in_channels),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()

        # 平均池化分支
        avg_out = self.avg_pool(x).view(b, c)
        avg_out = self.fc(avg_out).view(b, c, 1, 1)

        # 最大池化分支
        max_out = self.max_pool(x).view(b, c)
        max_out = self.fc(max_out).view(b, c, 1, 1)

        # 合并两个分支
        out = avg_out + max_out
        return out


class SpatialAttention(nn.Module):
    """空间注意力模块"""

    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size % 2 == 1, "Kernel size must be odd"
        padding = kernel_size // 2

        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 沿通道维度计算平均和最大值
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)

        # 拼接并卷积
        combined = torch.cat([avg_out, max_out], dim=1)
        spatial_att = self.conv(combined)

        return self.sigmoid(spatial_att)


class CrossStitchUnit(nn.Module):
    """Cross-stitch单元，允许任务之间共享信息"""

    def __init__(self, num_tasks=4, feature_size=32):
        super(CrossStitchUnit, self).__init__()
        self.num_tasks = num_tasks
        self.feature_size = feature_size

        # 创建可学习的权重矩阵
        self.weights = nn.Parameter(torch.eye(num_tasks))

    def forward(self, inputs):
        # 将输入堆叠为[batch_size, num_tasks, feature_size]
        stacked = torch.stack(inputs, dim=1)

        # 应用交叉连接权重
        cross_stitched = torch.einsum('btf,tc->bcf', stacked, self.weights)

        # 拆分为单独的任务特征
        outputs = torch.unbind(cross_stitched, dim=1)
        return outputs


class CNNInceptionHuigui(nn.Module):
    def __init__(self, input_size):
        super(CNNInceptionHuigui, self).__init__()
        self.input_size = input_size

        # 设置随机种子
        set_seed(2)

        # 初始卷积层 (使用残差块)
        self.conv0 = nn.Sequential(
            ResidualBlock(1, 6),  # 使用残差块替代普通卷积
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        # 第二卷积层 (使用残差块)
        self.conv1 = nn.Sequential(
            ResidualBlock(6, 12),  # 使用残差块替代普通卷积
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        # 新增第三卷积层 (使用残差块)
        self.conv2 = nn.Sequential(
            ResidualBlock(12, 24),  # 新增残差块层
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        # 转置卷积层
        self.trans_conv = nn.ConvTranspose2d(
            24, 32, kernel_size=3, stride=2, padding=1, output_padding=1  # 调整通道数
        )

        # Inception模块的分支 (使用残差连接)
        self.branch1x1 = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=1, padding='same'),
            ResidualBlock(32, 32)  # 添加残差块
        )

        self.branch3x3 = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=3, padding='same'),
            ResidualBlock(32, 32)  # 添加残差块
        )

        self.branch5x5 = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=5, padding='same'),
            ResidualBlock(32, 32)  # 添加残差块
        )

        self.branch_pool = nn.Sequential(
            nn.MaxPool2d(kernel_size=3, stride=1, padding=1),
            nn.Conv2d(32, 32, kernel_size=1, padding='same'),
            ResidualBlock(32, 32)  # 添加残差块
        )

        # 添加通道注意力模块
        self.channel_att = ChannelAttention(128, reduction_ratio=8)  # 4*32=128

        # 添加空间注意力模块
        self.spatial_att = SpatialAttention(kernel_size=7)

        # 后续层
        self.maxpool4 = nn.MaxPool2d(kernel_size=2, stride=2)

        # 新增全局平均池化层
        self.global_avg_pool = nn.AdaptiveAvgPool2d(1)

        # 计算全连接层输入大小
        self.fc_input_size = self._calculate_fc_input_size()

        # 共享特征提取层 (增加复杂度和防止过拟合)
        self.shared_fc = nn.Sequential(
            nn.Linear(self.fc_input_size, 128),  # 增加复杂度
            nn.LeakyReLU(negative_slope=0.01),
            nn.Dropout(0.2),  # 增加dropout比例
            nn.BatchNorm1d(128),  # 添加批归一化
            nn.Linear(128, 64),
            nn.LeakyReLU(negative_slope=0.01),
            nn.Dropout(0.2),
        )

        # 任务特定层 (添加残差连接)
        self.task_specific_layers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(64, 32),
                ResidualFCBlock(32, 32),  # 添加残差连接
                nn.LeakyReLU(negative_slope=0.01),
                nn.Dropout(0.2),
                nn.BatchNorm1d(32),  # 添加批归一化
            ) for _ in range(4)
        ])

        # Cross-stitch单元
        self.cross_stitch = CrossStitchUnit(num_tasks=4, feature_size=32)

        # 输出层
        self.output_layers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(32, 16),
                nn.LeakyReLU(negative_slope=0.01),
                nn.Linear(16, 1)
            ) for _ in range(4)
        ])

    def _calculate_fc_input_size(self):
        """计算全连接层的输入大小"""
        with torch.no_grad():
            x = torch.zeros(1, 1, self.input_size, self.input_size)
            x = self.conv0(x)
            x = self.conv1(x)
            x = self.conv2(x)  # 新增卷积层
            x = self.trans_conv(x)

            # Inception分支
            b1 = self.branch1x1(x)
            b2 = self.branch3x3(x)
            b3 = self.branch5x5(x)
            b4 = self.branch_pool(x)

            # 合并分支
            x = torch.cat([b1, b2, b3, b4], dim=1)  # 通道数变为128 (4*32)

            # 应用通道注意力
            channel_weights = self.channel_att(x)
            x = channel_weights * x

            # 应用空间注意力
            spatial_weights = self.spatial_att(x)
            x = spatial_weights * x

            x = self.maxpool4(x)
            x = self.global_avg_pool(x)  # 新增全局平均池化
            return x.numel() // x.size(0)  # 返回每个样本的特征数

    def forward(self, x, return_attention=False):
        # 前向传播
        x = self.conv0(x)
        x = self.conv1(x)
        x = self.conv2(x)  # 新增卷积层
        x = self.trans_conv(x)

        # Inception模块
        b1 = self.branch1x1(x)
        b2 = self.branch3x3(x)
        b3 = self.branch5x5(x)
        b4 = self.branch_pool(x)

        # 合并分支
        x = torch.cat([b1, b2, b3, b4], dim=1)  # 通道数变为128

        # 应用通道注意力
        channel_weights = self.channel_att(x)
        x_channel_att = channel_weights * x

        # 应用空间注意力
        spatial_weights = self.spatial_att(x_channel_att)
        x_spatial_att = spatial_weights * x_channel_att

        # 后续处理
        x = self.maxpool4(x_spatial_att)
        x = self.global_avg_pool(x)  # 全局平均池化
        x = x.view(x.size(0), -1)  # 展平

        # 共享特征提取
        shared_features = self.shared_fc(x)

        # 任务特定特征提取
        task_features = [layer(shared_features) for layer in self.task_specific_layers]

        # Cross-stitch单元进行任务间信息共享
        cross_stitched_features = self.cross_stitch(task_features)

        # 最终输出
        outputs = [output_layer(feature) for output_layer, feature in zip(self.output_layers, cross_stitched_features)]
        outputs = torch.cat(outputs, dim=1)  # [batch_size, 4]

        if return_attention:
            return outputs, channel_weights, spatial_weights
        return outputs


class ResidualFCBlock(nn.Module):
    """全连接残差块"""

    def __init__(self, in_features, out_features):
        super(ResidualFCBlock, self).__init__()

        self.fc1 = nn.Sequential(
            nn.Linear(in_features, out_features),
            nn.LeakyReLU(negative_slope=0.01)
        )

        self.fc2 = nn.Sequential(
            nn.Linear(out_features, out_features),
            nn.LeakyReLU(negative_slope=0.01)
        )

        self.shortcut = nn.Sequential()
        if in_features != out_features:
            self.shortcut = nn.Sequential(
                nn.Linear(in_features, out_features),
                nn.LeakyReLU(negative_slope=0.01)
            )

    def forward(self, x):
        identity = x

        out = self.fc1(x)
        out = self.fc2(out)

        identity = self.shortcut(identity)
        out += identity
        return out

