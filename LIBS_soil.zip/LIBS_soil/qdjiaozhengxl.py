import numpy as np
import pandas as pd
from scipy.signal import find_peaks
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
from sklearn.preprocessing import minmax_scale


def qdjiaozhengxl(file_path):
    # 读取TXT文件数据
    data = pd.read_csv(file_path, sep='\s+').values#file_path

    # 获取波长和强度
    wavelengths = data[1:, 0]  # 第一列是波长（跳过标题行）
    intensities = data[1:, 1]  # 第二列是强度

    # 最小-最大归一化
    intensities01 = minmax_scale(intensities)

    # 预定义的波长列表
    b = np.array([202.5, 206.2, 213.8, 226.5, 228.8, 251.612, 252.45, 261.4, 279.55, 280.27, 282.2, 285.213, 299.1,
                  302.15, 308.1, 309.1, 315.88, 317.9, 324.75, 327.4, 334.5, 341.42, 345, 346.62, 357.89, 359.36,
                  360.56, 365.0, 369.39, 370.5, 373.486, 373.6, 383.83, 393.36, 396.8, 404.58, 405.85, 422.74, 425.435,
                  427.52, 458.596, 588.9, 589.59, 670.5, 744.23, 746.82, 766.24, 769.89, 777.5, 844, 845])

    # 寻找在b±1范围内的波长
    indices = []
    for i, wl in enumerate(wavelengths):
        if np.any(np.abs(b - wl) <= 0.5):
            indices.append(i)

    wavelengths1 = wavelengths[indices]
    intensities1 = intensities01[indices]

    # 自动寻峰（特征峰）
    peaks1, locations1 = find_peaks(intensities1, height=0.001, distance=5)
    peaks2, locations2 = find_peaks(intensities01, height=0.1, distance=10)

    ab1 = wavelengths1[peaks1]
    ab2 = wavelengths[peaks2]
    ab = np.unique(np.concatenate((ab1, ab2)))

    # 矫正部分
    ac = []
    for wl in ab:
        matching_rows = data[data[:, 0] == wl]
        if len(matching_rows) > 0:
            ac.append(matching_rows[0])  # 取第一个匹配行

    ac = np.array(ac).T
    labels = data[0, 1:]  # 第一行是标签
    features = ac[1:, :]  # 特征值

    # 计算每个标签下的特征均值
    unique_labels = np.unique(labels)
    d = np.zeros((len(unique_labels), features.shape[1]))

    for i in range(len(unique_labels)):
        current_features = features[labels == unique_labels[i], :]
        d[i, :] = np.mean(current_features, axis=0)

    d = np.column_stack((unique_labels, d))
    x = d[:, 0] / 100
    v = d[0, 1:] / d[:, 1:]
    K = (1 - x[:, np.newaxis]) * v

    # 定义拟合函数
    def exp_func(x, a, b):
        return a * np.exp(b * x) - a + 1

    def linear_func(x, a, b):
        return a * x + b

    # 存储拟合结果
    fit_params = []
    mo = K.shape[1]

    for e in range(mo):
        y_data = K[:, e]
        current_params = {'model': None, 'a': None, 'b': None, 'R2': -np.inf}

        # 尝试指数拟合
        try:
            popt_exp, _ = curve_fit(exp_func, x, y_data, p0=[1, 0.1])
            y_exp_fit = exp_func(x, *popt_exp)

            # 计算R²
            ss_total = np.sum((y_data - np.mean(y_data)) ** 2)
            ss_residual = np.sum((y_data - y_exp_fit) ** 2)
            R2_exp = 1 - (ss_residual / ss_total)

            if R2_exp > current_params['R2']:
                current_params.update({
                    'model': 'exp',
                    'a': popt_exp[0],
                    'b': popt_exp[1],
                    'R2': R2_exp,
                    'y_fit': y_exp_fit
                })
        except:
            pass

        # 尝试线性拟合
        try:
            popt_linear, _ = curve_fit(linear_func, x, y_data, p0=[1, 1])
            y_linear_fit = linear_func(x, *popt_linear)

            ss_residual = np.sum((y_data - y_linear_fit) ** 2)
            R2_linear = 1 - (ss_residual / ss_total)

            if R2_linear > current_params['R2']:
                current_params.update({
                    'model': 'linear',
                    'a': popt_linear[0],
                    'b': popt_linear[1],
                    'R2': R2_linear,
                    'y_fit': y_linear_fit
                })
        except:
            pass

        fit_params.append(current_params)

    # 打印结果
    for e, params in enumerate(fit_params, 1):
        print(f'曲线 {e}: 模型={params["model"]}, a={params["a"]:.4f}, b={params["b"]:.4f}, R²={params["R2"]:.4f}')
    # 保存 ab 和 mo 为 numpy 数组文件
    np.save('ab.npy', ab)
    np.save('mo.npy', mo)
    # 保存拟合参数（需要先确保fit_params是字典列表）
    fit_params_dict = {i: params for i, params in enumerate(fit_params)}
    np.save('fit_params.npy', fit_params_dict)
    return ab, mo, fit_params


# 使用示例
if __name__ == "__main__":
    # 假设有一个TXT文件，格式为：第一行是标签，第一列是波长，其余是强度数据
    file_path = 'C:\LIBS车载\标准文件\车载水分.txt'
    ab, mo, fit_params = qdjiaozhengxl(file_path)
